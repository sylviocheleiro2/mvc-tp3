﻿
using System.ComponentModel.DataAnnotations;

namespace CadastroClienteMVC.Models
{
	public class Cliente
	{
		public int Id { get; set; }
		[Required]
		public string Name { get; set; }
        [Required]
        public string CPF { get; set; }
        [Required]
        public string Email { get; set; }
        [Required]
        public DateTime Nascimento { get; set; }
       
    }
}
