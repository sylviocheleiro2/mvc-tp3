﻿using CadastroClienteMVC.Mapping;
using CadastroClienteMVC.Models;
using Microsoft.EntityFrameworkCore;

namespace CadastroClienteMVC
{
	public class ClienteContext : DbContext
	{
        public DbSet<Cliente> CLientes { get; set; }
        public ClienteContext(DbContextOptions<ClienteContext> options) 
			: base(options)
		{

		}
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new ClienteMapping());
          
            base.OnModelCreating(modelBuilder);
        }
    }
}
